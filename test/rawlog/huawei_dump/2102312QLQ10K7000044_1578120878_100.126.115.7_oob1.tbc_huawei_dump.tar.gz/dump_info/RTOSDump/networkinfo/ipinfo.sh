"""ifconfig eth2 hw ether 08:4f:0a:e6:65:a8"/sbin/dhclient4_eth2 -4 eth2 -cf /etc/dhclient_ip.conf > /tmp/missing 2>&1 &
